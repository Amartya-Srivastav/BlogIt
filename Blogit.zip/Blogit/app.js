var app = angular.module('myApp', ['ngRoute']);

app.config(function($routeProvider ,$locationProvider){
    $locationProvider.hashPrefix(''); 
    Stamplay.init("bloggit1");
    localStorage.clear();
    $routeProvider
    .when('/',{
        templateUrl:'bower_components/templates/home.html',
        controller :"HomeCtrl"
    })
    .when('/login',{
        templateUrl : 'bower_components/templates/login.html',
        controller : "LoginCtrl"
    })
    .when('/signup',{
        templateUrl : 'bower_components/templates/signup.html',
        controller : "SignUpCtrl"
    })
})

app.controller ("LoginCtrl",function($scope){
$scope.login=function(){
    Stamplay.User.currentUser()
    .then(function(respond){
        console.log(respond);
        if(respond.user){
            $timeout(function(){
            $location.path("/viewBlogs")});
        }
        else{

        }
    },function(erro){
        console.log(erro);
    })
}
});
/*app.controller('HomeCtrl' ,function($scope ,$http){
var API_KEY='f105a57b9a95bc02acc2428b98363b93';
http.get("http://api.openweathermap.org/data/2.5/weather?q=bangalore&appid="+API_KEY)
.then(success,failure);
function success(data){
    console.log(data);
}
function failure(err){
    console.log(err);
}
});*/
app.controller('SignUpCtrl',function($scope){
    $scope.newUser = { };
    $scope.signup=function(){
        if($scope.newUser.firstName && $scope.newUser.lastName && $scope.newUser.email && $scope.newUser.password && 
            $scope.newUser.confirmPassword ){
            console.log("all fields are filled");
            if ($scope.newUser.Password == $scope.newUser.ConfirmPassword){
            console.log("passwords do match");
                Stamplay.User.signup($scope.newUser)
                .then(function(response){
                    console.log(response);
                },function(err){
                    console.log(err)});
            }
            else
            console.log("passwords doesn't match!");
            }
        else
         console.log("some fields are not filled!");
    }

})

